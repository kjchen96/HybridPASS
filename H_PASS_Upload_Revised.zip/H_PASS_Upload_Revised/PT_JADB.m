function [F_RF,F_BB,rate_store] =  PT_JADB(N_t,N_r,N_p,N_RF,sigma2,P_tx,K,H, rho_scale)
%PT_JADB  Proximal-toolbox based joint design for discrete PA placement (DH/DP/R-PASS baselines)
%
%   [F_RF, F_BB, rate_store] = PT_JADB(N_t, N_r, N_p, N_RF, sigma2, P_tx, K, H, rho_scale)
%
% This routine implements the iterative updates used in the paper to design:
%   - The analog precoder F_RF and the digital precoder F_BB; and
%   - (When applicable) the discrete selection of pinching-antenna (PA) positions on a candidate grid.
%
% Inputs
%   N_t       : number of candidate PA positions on the discrete grid (per array)
%   N_r       : number of RLWAs per waveguide
%   N_p       : number of active PAs per waveguide (set to 0 for the R-PASS baseline)
%   N_RF      : number of waveguides / RF chains
%   sigma2    : noise power (normalized)
%   P_tx      : total transmit power (linear scale)
%   K         : number of users
%   H         : composite channel matrix (size: N_total x K)
%   rho_scale : multiplicative factor used to update the penalty parameter rho
%
% Outputs
%   F_RF      : analog (RF) precoder
%   F_BB      : digital (baseband) precoder
%   rate_store: sum-rate trajectory across iterations
    Ns = N_t/N_RF;            % Number of Antennas for Each Waveguide
    N_c = Ns - N_r;
    HalfN = N_c/2;

    % Initialization
    F_RF = zeros(N_t,K);
    for k = 1 : K
        ht = H((k-1)*Ns+1:k*Ns,k);
        for nn = 1 : Ns
            if (nn >= HalfN + 1) && (nn <= HalfN + N_r)
                F_RF((k-1)*Ns+nn,k) = exp(1j * angle(ht(nn)));
            else
                if abs(angle(ht(nn)))<= pi/4
                    F_RF((k-1)*Ns+nn,k) = 1;
                end
            end
        end
    end
    F = F_RF;
    F = F/norm(F,'fro') * sqrt(P_tx);
    rate_old = sum_rate_cal(H,F,sigma2,K);
    F_RF = F;
    F_BB = eye(N_RF);


    rho = 1;
    rate_store = rate_old;
    RateOld = 0;
    for out_iter = 1 : 300   % outer loop
        for in_iter = 1 : 50
            %-----------------------------optimize u-----------------------------
            u = zeros(1,K);
            for k = 1 : K
                u(k) = F(:,k)' * H(:,k)/(sum(abs(H(:,k)' * F).^2) + sigma2 * norm(F,'fro')^2/P_tx);
            end

            %-----------------------------optimize v-----------------------------
            v = zeros(1,K);
            for k = 1 : K
                hkF = H(:,k)' * F;                 % 1×K
                noise_eff = sigma2 * norm(F,'fro')^2 / P_tx;
                e_k = abs(1 - u(k)*hkF(k))^2 ...
                + abs(u(k))^2 * ( sum(abs(hkF).^2) - abs(hkF(k))^2 + noise_eff );
                v(k) = 1 / e_k;
            end

            % -----------------------------optimize F-----------------------------
            % -----------------Compute the inverse using the Woodbury identity----------------------------
            % H_eff
            H_eff = zeros(N_t, K);
            a_vec = zeros(K, 1);
            for k = 1:K
                a_vec(k) = abs(u(k))^2 * v(k);
                H_eff(:,k) = sqrt(a_vec(k)) * H(:,k);
            end

            % alpha
            alpha = 1/(2*rho) + sigma2/P_tx * sum(a_vec);

            temp = (eye(K) + (1/alpha) * (H_eff' * H_eff));  % size KxK
            A_inv = temp \ eye(K);

            %         inv_R = (1/alpha) * (eye(N_t) - (1/alpha) * H_eff * A_inv * H_eff');



            for k = 1 : K
                f_k_tilde = F_RF * F_BB(:,k);
                eta = v(k) * conj(u(k)) * H(:,k) + f_k_tilde/2/rho;
                %             F(:,k) = inv_R * eta;

                F(:,k) = (1/alpha) * (eta - (1/alpha) * (H_eff * (A_inv * (H_eff' * eta)) ));
            end

            % -----------------------------Optimize B-----------------------------
            %         F_k_line = F;
            %         F_RF = zeros(N_t,N_RF);
            %         for mm = 1 : N_RF
            %             LossStore = inf * ones(Ns,1);
            %             for nn = 1 : Ns
            %                 tt = (mm - 1) * Ns + nn;
            %                 ft = F(tt,:).';
            %                 fbt = F_BB(mm,:).';
            %                 if (nn >= HalfN + 1) && (nn <= HalfN + N_r)
            %                     alpha = fbt' * ft/(fbt' * fbt);
            %                     if abs(alpha) > 1
            %                        F_RF(tt,mm) = exp(1j * angle(alpha));
            %                     else
            %                        F_RF(tt,mm) = alpha;
            %                     end
            %                 else
            %                     Loss2 = norm(ft - fbt);
            %                     LossStore(nn) = Loss2;
            %                 end
            %             end
            %             [~,Index] = sort(LossStore,'ascend');
            %             F_RF((mm - 1) * Ns + Index(1:N_p),mm) = 1;
            %         end
            F_k_line = F;
            F_RF = zeros(N_t, N_RF);

            eps_denom = 1e-12;  % Prevent fbt'*fbt is too small

            for mm = 1:N_RF
                fbt = F_BB(mm,:).';                  % w_m  (Kx1)
                denom = real(fbt' * fbt) + eps_denom;

                gain = -inf(Ns, 1);                 

                for nn = 1:Ns
                    tt = (mm - 1) * Ns + nn;
                    ft = F(tt,:).';                 % f_{bp,m,n} (Kx1)

                    if (nn >= HalfN + 1) && (nn <= HalfN + N_r)
                        % ---------- RLWA  ----------
                        alpha = (fbt' * ft) / denom;
                        if abs(alpha) > 1
                            F_RF(tt, mm) = exp(1j * angle(alpha));
                        else
                            F_RF(tt, mm) = alpha;
                        end

                    else
                        % ---------- PA：Compute loss reduction： ||ft||^2 - ||ft - fbt||^2 ----------
                        loss0 = real(ft' * ft);
                        diff  = ft - fbt;
                        loss1 = real(diff' * diff);
                        gain(nn) = loss0 - loss1;   
                    end
                end

                [~, idx] = sort(gain, 'descend');
                pick = idx(1:N_p);
                F_RF((mm - 1) * Ns + pick, mm) = 1;
            end

            % -----------------------------optimize F_BB-----------------------------
            F_BB  = inv(F_RF' * F_RF) * F_RF' * F_k_line;
            Ratenew = RateCal(H,F_RF,F_BB,P_tx,sigma2,K);
            if abs(Ratenew - RateOld)< 1e-2
                break;
            end
            RateOld = Ratenew;
        end
        [rate_store] = [rate_store,RateOld];
        rho = rho * rho_scale;
        %     if out_iter > 50 
        %         rho_scale = 0.8;
        %     end

        if out_iter > 100  && abs(rate_store(out_iter) - rate_store(out_iter-10))<0.1
            break; 
        end
    end
    F_BB = F_BB/norm(F_RF * F_BB,'fro') * sqrt(P_tx);
end


function Ratenew = RateCal(H,F_RF,F_BB,P_tx,sigma2,K)

    F_BB = F_BB/norm(F_RF * F_BB,'fro') * sqrt(P_tx);
    % sum-rate calculation
    Ratenew = sum_rate_cal(H,F_RF * F_BB,sigma2,K);

end
