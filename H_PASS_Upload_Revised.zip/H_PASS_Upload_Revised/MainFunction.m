% MainFunction  Reproduce the numerical results and figures for the H-PASS simulation
%
% This script:
%   1) Generates the composite channel matrix for the considered H-PASS architecture;
%   2) Runs the proposed benchmark/algorithm modules (PT_JADB, AM_JPOB, etc.);
%   3) Plots the average sum spectral efficiency versus SNR.
%
% Notation (consistent with the accompanying paper):
%   N_RF : number of waveguides / RF chains
%   N_t  : number of candidate PA positions on the discrete grid
%   N_r  : number of RLWAs per waveguide
%   N_p  : number of active pinching antennas per waveguide
%   K    : number of users
%   sigma2 : noise power (normalized)
%   P_tx : total transmit power (linear scale)

clear all;
close all;
%% Setting
c0 = 3e8;            % Speed of light (m/s)
f_c = 30e9;          % Carrier frequency (Hz)
lambda_c = c0/f_c;      % Wavelength in free space (m)
N_t = 1000;            % Number of candidate PA positions (discrete grid)
d_pa = lambda_c/2 * 8;    % Antenna Spacing for Candidate Discrete-Position PAs
d_rlwa = lambda_c/2;        % Antenna Spacing for RLWAs

d_min_norm = lambda_c/2;   % Minimum Spacing for Continuous-Position PAs
K = 4;               % Number of Users
N_RF = 4;              % Number of Waveguides/RF chains
N_s = N_t/N_RF;          % Number of Antennas in each waveguide
%% Monte Carol Simulation
N_r = 8;               % Number of RLWAs
N_p = 16;              % Number of PAs
%% Basic Setting
D = (N_s-N_r) * d_pa + N_r * d_rlwa;         % Array Aperture
L = 6;              % Number of Channel Paths
sigma2 = 1;
%% Coordinate
Height = 3;          % Height of Waveguides
Width = 10;          % width of the service region
Length = 30;         % length of the service region
bsAxisX = kron(linspace(Length/2/N_RF,Length-Length/2/N_RF,N_RF)',ones(N_s,1));                     % Candidate Antennas x-axis 
% bsAxisX = 0;
[bsAxisY_grid,x_left, x_middle, x_right] = generate_array_positions(N_s, N_r, d_pa, d_rlwa);
bsAxisY = kron(ones(N_RF,1),bsAxisY_grid');     % Candidate Antennas y-axis 
bsAxisZ = ones(N_t,1) * Height;             % Candidate Antennas z-axis 
bsAxisY2 = kron(ones(N_RF,1),(-(N_s-1)/2 : 1 : (N_s-1)/2)' * d_pa); % Candidate Antennas y-axis 

r_min = [0,-Width/2];                       % minimum communication distance
r_max = [Length,Width/2];                   % maximum communication distance
% Boundaries for Continuous-Position PAs
userYMin = zeros(N_RF,1);
userYMax = zeros(N_RF,1);
userYMinRegion2 = zeros(N_RF,1);
userYMaxRegion2 = zeros(N_RF,1);
userYMinRegion3 = zeros(N_RF,1);
userYMaxRegion3 = zeros(N_RF,1);
waveguidePosNormGrid = zeros(N_RF,1);
for ii = 1 : N_RF
    userYMin(ii) = -D/2;
    userYMax(ii) = D/2;
    userYMinRegion2(ii) = x_left(1);
    userYMaxRegion2(ii) = x_left(end);
    userYMinRegion3(ii) = x_right(1);
    userYMaxRegion3(ii) = x_right(end);
end



%% Transmit Power
noisePowerLin = 10^(-11);             % linear
%% Start
% Channel Generation
[H,H2,channelParam] = ChannelGenerationContinuous(N_t,K,L,r_min,r_max,bsAxisX,bsAxisY,bsAxisY2,bsAxisZ,lambda_c);

% Power Normarlization to prevent numerical inaccuracy due to very small values
TransmitPowerdBM = 10;
P_tx = 10^((TransmitPowerdBM - 30)/10);
channelGainScale = 1/(mean(abs(H(:)).^2));
H = H * sqrt(channelGainScale);   % Normalize the average channel power (squared magnitude) to 1
H2 = H2 * sqrt(channelGainScale);
P_tx = 1/noisePowerLin/channelGainScale * P_tx; % Adjust transmit power so that the noise power is 1

%% Hybrid PASS with Discrete-Position Passive PAs
[F_RF_DH,F_BB_DH,rateStore_DH] =  PT_JADB(N_t,N_r,N_p,N_RF,sigma2,P_tx,K,H,0.9);
%% Hybrid PASS with Continuous-Position Passive PAs
init_CH = Initial_AM_JPOB(F_RF_DH,F_BB_DH,N_RF,N_t,N_r,N_p,bsAxisY,H);      
[F_RF_CH,F_BB_CH,rateStore_CH,Position2,TradeOffStore2] = AM_JPOB(N_r,N_RF,sigma2,P_tx,K,N_p,d_min_norm,lambda_c,channelParam,bsAxisX,userYMinRegion2,userYMaxRegion2,userYMinRegion3,userYMaxRegion3,waveguidePosNormGrid,channelGainScale,init_CH);
%% R-PASS
[F_RF_R,F_BB_R,rateStore_R] =  PT_JADB(N_t,N_r,0,N_RF,sigma2,P_tx,K,H,0.9);
%% P-PASS with Discrete-Position Passive PAs
[F_RF_DP,F_BB_DP,rateStore_DP] =  PT_JADB(N_t,0,N_p,N_RF,sigma2,P_tx,K,H2,0.9);
%% P-PASS with Continuous-Position Passive PAs
init_CP = Initial_AM_JPOB_withoutActive(F_RF_DP,F_BB_DP,N_t,N_RF,N_p,bsAxisY2);      
[F_RF_CP,F_BB_CP,rateStore_CP,Position5,TradeOffStore5] = AM_JPOB_withoutActive(N_RF,sigma2,P_tx,K,N_p,d_min_norm,lambda_c,channelParam,bsAxisX,userYMin,userYMax,waveguidePosNormGrid,channelGainScale,init_CP);


%% Plot Figure
plot(rateStore_DH(2:end),'kx-','linewidth',1.5,'markersize',8);
hold on;
plot(rateStore_CH,'mp-','linewidth',1.5,'markersize',8);
plot(rateStore_R(2:end),'>-','color',[0 0.5 0],'linewidth',1.5,'markersize',8);
plot(rateStore_DP(2:end),'bo-','linewidth',1.5,'markersize',8);
plot(rateStore_CP,'rs-','linewidth',1.5,'markersize',8);

legend({'DH-PASS','CH-PASS','R-PASS','DP-PASS','CP-PASS'}, 'Interpreter','latex','Location','best');