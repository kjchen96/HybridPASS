function [F_RF,F_BB,rate_store,Position,tradeoff_store] = AM_JPOB_withoutActive(N_RF,sigma2,P_tx,K,N_p,d_min_norm,lambda_c,channelParam,bsAxisX,userYMin,userYMax,waveguidePosNormGrid,channelGainScale,initData)
%AM_JPOB_withoutActive  Alternating minimization for CP-PASS (passive-only baseline)
%
%   [F_RF, F_BB, rate_store, Position, tradeoff_store] = AM_JPOB_withoutActive( ...
%       N_r, N_RF, sigma2, P_tx, K, N_p, d_min_norm, lambda_c, channelParam, bsAxisX, ...
%       userYMin, userYMax, userYMinRegion3, userYMaxRegion3, waveguidePosNormGrid, channelGainScale, initData)
%
% This variant corresponds to the passive-only case in the paper (CP-PASS).
    neff = 1.44;
    lambda_g = lambda_c/neff;


    N_t =  N_p * N_RF;

    Aneq = zeros((N_p - 1) * N_RF,N_p * N_RF);
    for ii = 1 : N_RF
        for jj = 1 : N_p -1
            index = (ii - 1) * N_p +jj;
            row = (ii - 1) * (N_p -1) + jj;
            Aneq(row,index) = 1;
            Aneq(row,index + 1) = -1;
        end
    end
    bneq = -ones((N_p - 1) * N_RF,1) * d_min_norm;
    % Position Initialization
    AntennaPostion =  initData.Position;
    AntennaPostionIni = AntennaPostion;
    % PA Channel Generation
    Hp = sqrt(channelGainScale) * ChannelGenerationPassive(AntennaPostion,channelParam,bsAxisX,lambda_c,lambda_g,waveguidePosNormGrid,N_RF);


    % Initialize Beamformers
    F_RF = initData.Frf;
    F_BB = initData.Fbb;
    rate_old = sum_rate_cal(Hp,F_RF * F_BB,sigma2,K);


    % Update F
    Fp = F_RF * F_BB;


    rate_store = rate_old;
    RateOld = 0;
    tradeoff_store = [];
    for in_iter = 1 : 50
        %-----------------------------optimize u-----------------------------
        u = zeros(1,K);
        for kk = 1 : K
            u(kk) = Fp(:,kk)' * Hp(:,kk)/(sum(abs(Hp(:,kk)' * Fp).^2) + sigma2);
        end
        if in_iter > 1
            tradeoff_store = [tradeoff_store, TradeOffCalculate(Hp,Fp,u,v,K,sigma2)];
        end
        %-----------------------------optimize v-----------------------------
        v = zeros(1,K);
        for kk = 1 : K
            %         e_k = sigma2 * abs(u(kk))^2  + abs(1 - u(kk) * Hp(:,kk)' * Fp(:,kk))^2 + sum(abs(u.* (Hp(:,kk)' * Fp)).^2) - abs(u(kk)* (Hp(:,kk)' * Fp(:,kk))).^2;
            %         v(kk) = 1/e_k;
            hkF = Hp(:,kk)' * Fp;   % 1xK
            e_k = abs(1 - u(kk)*hkF(kk))^2 ...
            + abs(u(kk))^2 * (sum(abs(hkF).^2) - abs(hkF(kk))^2 + sigma2);
            v(kk) = 1 / e_k;
        end

        if in_iter > 1
            tradeoff_store = [tradeoff_store, TradeOffCalculate(Hp,Fp,u,v,K,sigma2)];
        end
        % -----------------------------optimize yk-----------------------------
        objective_function = @(x) OnlyPassivePinchingAntennaPositionOptimizationObj(x,channelParam,bsAxisX,lambda_c,lambda_g,waveguidePosNormGrid,N_RF,u,v,Fp,channelGainScale);
        options = optimoptions('fmincon', 'Algorithm', 'sqp', 'Display', 'iter');
        lb  = kron(userYMin,ones(N_p,1));
        ub = kron(userYMax,ones(N_p,1));
        [AntennaPostionNew, ~] = fmincon(objective_function, AntennaPostionIni', Aneq, bneq, [], [], lb,ub, [],options);
        %     [AntennaPostionNew, ~] = fmincon(objective_function, AntennaPostionIni', Aneq, bneq, [], [], lb,ub);
        Hp = sqrt(channelGainScale) * ChannelGenerationPassive(AntennaPostionNew',channelParam,bsAxisX,lambda_c,lambda_g,waveguidePosNormGrid,N_RF);
        AntennaPostionIni = AntennaPostionNew';


        tradeoff_store = [tradeoff_store, TradeOffCalculate(Hp,Fp,u,v,K,sigma2)];


        % -----------------------------Optimize F_BB-----------------------------
        Overline_Hk = zeros(K,K);
        for kk = 1 : K
            Overline_Hk(kk,:) = u(kk) * Hp(:,kk)' * F_RF;
        end
        T = zeros(K,K);
        S = zeros(K,K);
        for kk = 1 : K
            T = T + v(kk) * Overline_Hk(kk,:)' * Overline_Hk(kk,:);
            S(:,kk) = v(kk) * Overline_Hk(kk,:)';
        end
        overlineP = kron(eye(K),T);
        overlinep = S(:);
        overlineFrf = kron(eye(K),F_RF);
        cvx_begin quiet
        variable fbb(K^2,1) complex
        minimize(( quad_form(fbb, overlineP) - 2 * real(overlinep' * fbb) ) )
        subject to
        norm(overlineFrf * fbb) <= sqrt(P_tx);
        cvx_end
        % Reconstruct F_BB
        F_BB = reshape(fbb,K,K);
        % Reconstruct F;
        Fp = F_RF * F_BB;


        tradeoff_store = [tradeoff_store, TradeOffCalculate(Hp,Fp,u,v,K,sigma2)];

        % -----------------------------Rate Calculation-----------------------------
        Ratenew = RateCal(Hp,F_RF,F_BB,P_tx,sigma2,K);
        [rate_store] = [rate_store,Ratenew];
        %     if abs(Ratenew - RateOld)< 1e-2
        %         break;
        %     end
        RateOld = Ratenew;

        if in_iter > 40 
            if (rate_store(in_iter) - rate_store(in_iter-1))<0.02
                break;
            end
        end
    end
    Position = AntennaPostionNew;
end


function Ratenew = RateCal(H,F_RF,F_BB,P_tx,sigma2,K)

    F_BB = F_BB/norm(F_RF * F_BB,'fro') * sqrt(P_tx);
    % Rate Calculation
    Ratenew = sum_rate_cal(H,F_RF * F_BB,sigma2,K);

end

function tradeoff = TradeOffCalculate(H,F,u,v,K,sigma2)
    tradeoff = 0;

    for kk = 1 : K
        ek = abs(u(kk))^2 * sigma2;
        for ii = 1 : K
            if  ii ~= kk
                ek = ek + abs(u(kk) * H(:,kk)' * F(:,ii))^2;
            else
                ek = ek + abs(u(kk) * H(:,kk)' * F(:,ii) - 1)^2;
            end
        end
        tradeoff = tradeoff + v(kk) * ek - log(v(kk));
    end

end
