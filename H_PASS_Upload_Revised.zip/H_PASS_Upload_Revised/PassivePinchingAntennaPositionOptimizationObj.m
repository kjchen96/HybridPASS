function   objective_function = PassivePinchingAntennaPositionOptimizationObj(x,channelParam,bsAxisX,lambda_c,lambda_g,waveguidePosNormGrid,N_RF,u,v,Ha,Fa,Fp,channelGainScale) 
%PassivePinchingAntennaPositionOptimizationObj  Objective function for joint active+passive PA position updates
%
% This objective is used by AM_JPOB to evaluate/update continuous PA positions under the
% geometry/channel model defined in channelParam.
%

    x = x';
    objective_function = 0;
    Hp = sqrt(channelGainScale) * ChannelGenerationPassive(x,channelParam,bsAxisX,lambda_c,lambda_g,waveguidePosNormGrid,N_RF);

    for kk = 1 : N_RF
        ek = abs(1 - u(kk) * Ha(:,kk)' * Fa(:,kk) - u(kk) * Hp(:,kk)' * Fp(:,kk))^2 +...
        sum(abs(u.* (Ha(:,kk)' * Fa + Hp(:,kk)' * Fp) ).^2)   - ...
        abs(u(kk)* (Ha(:,kk)' * Fa(:,kk) + Hp(:,kk)' * Fp(:,kk))).^2;
        objective_function = objective_function + v(kk) * ek;
    end

end
