function [F_RF,F_BB,rate_store,Position,tradeoff_store] =  AM_JPOB(N_r,N_RF,sigma2,P_tx,K,N_p,d_min_norm,lambda_c,channelParam,bsAxisX,userYMinRegion2,userYMaxRegion2,userYMinRegion3,userYMaxRegion3,waveguidePosNormGrid,channelGainScale,initData)
%AM_JPOB  Alternating minimization for joint hybrid precoding and continuous PA placement (CH/CP-PASS)
%
%   [F_RF, F_BB, rate_store, Position, tradeoff_store] = AM_JPOB( ...
%       N_r, N_RF, sigma2, P_tx, K, N_p, d_min_norm, lambda_c, channelParam, bsAxisX, ...
%       userYMinRegion2, userYMaxRegion2, userYMinRegion3, userYMaxRegion3, ...
%       waveguidePosNormGrid, channelGainScale, initData)
%
% This routine follows the paper's alternating-minimization steps to jointly update:
%   - The hybrid precoder (F_RF, F_BB); and
%   - The continuous pinching-antenna positions (Position) under a minimum-spacing constraint.
%
% Inputs
%   N_r, N_RF, N_p     : antenna/waveguide dimensions (see MainFunction for definitions)
%   sigma2, P_tx, K    : noise power, transmit power, and number of users
%   d_min_norm         : minimum adjacent-PA spacing constraint (normalized)
%   lambda_c           : carrier wavelength in free space (m)
%   channelParam       : struct holding geometry/channel parameters produced by ChannelGenerationContinuous
%   bsAxisX            : x-axis coordinates used in the geometry model
%   userYMin/MaxRegion : user-region boundaries used in the geometry model
%   waveguidePosNormGrid : normalized candidate grid along each waveguide (for initialization/projection)
%   channelGainScale   : channel normalization scalar used consistently across the simulation
%   initData           : initialization returned by Initial_AM_JPOB
%
% Outputs
%   F_RF, F_BB         : analog and digital precoders
%   rate_store         : sum-rate trajectory across iterations
%   Position           : optimized continuous PA positions
%   tradeoff_store     : stored objective/penalty components (as in the original implementation)

    neff = 1.44;
    lambda_g = lambda_c/neff;


    N_t = (N_r + N_p) * N_RF;
    Ns = N_t/N_RF;

    % 
    Aneq = zeros((N_p - 1) * N_RF,N_p * N_RF);
    for ii = 1 : N_RF
        for jj = 1 : N_p -1
            index = (ii - 1) * N_p +jj;
            row = (ii - 1) * (N_p -1) + jj;
            Aneq(row,index) = 1;
            Aneq(row,index + 1) = -1;
        end
    end
    bneq = -ones((N_p - 1) * N_RF,1) * d_min_norm;


    % Position Initialization
    AntennaPostion =  initData.Position;
    AntennaPostionIni = AntennaPostion;
    H = initData.H;
    Hr = H;
    % Boundary Generation
    lb  = zeros(N_RF * N_p,1);
    ub = zeros(N_RF * N_p,1);
    for ii = 1 : N_RF * N_p
        jj = ceil(ii/N_p);
        if (AntennaPostionIni(ii) >=  userYMinRegion2(jj)) && (AntennaPostionIni(ii) <=  userYMaxRegion2(jj))
            lb(ii) = userYMinRegion2(jj);
            ub(ii) = userYMaxRegion2(jj);
        else
            lb(ii) = userYMinRegion3(jj);
            ub(ii) = userYMaxRegion3(jj);
        end
    end



    % PA Channel Generation
    Hp = sqrt(channelGainScale) * ChannelGenerationPassive(AntennaPostion,channelParam,bsAxisX,lambda_c,lambda_g,waveguidePosNormGrid,N_RF);
    % RLWA Channel Generation
    Ha = zeros(N_r * N_RF, N_RF);
    Nsr = size(H,1)/N_RF;
    for kk = 1 : N_RF
        Ha((kk-1)*N_r +1 : kk*N_r,:) = Hr((kk-1)*Nsr +1 : (kk-1)*Nsr + N_r,:);
    end

    % Channel Update
    H = zeros(N_t,N_RF);
    for kk = 1 : N_RF
        H((kk-1)*Ns +1 : (kk-1)*Ns + N_r,:) = Ha((kk-1)*N_r +1 : kk*N_r,:);
        H((kk-1)*Ns +1 + N_r :  kk * Ns,:) = Hp((kk-1)*N_p +1 :  kk * N_p,:);
    end

    % Initialize Beamformers
    F_RF = initData.Frf;
    F_BB = initData.Fbb;
    rate_old = sum_rate_cal(H,F_RF * F_BB,sigma2,K);


    % Update F
    F = F_RF * F_BB;
    % Update Fa 和 Fp
    Fa = zeros(N_r * N_RF,N_RF);
    Fp = zeros(N_p * N_RF,N_RF);
    for kk = 1 : N_RF
        Fa((kk-1) * N_r + 1 :  kk * N_r,:) = F((kk-1) * Ns + 1 : (kk-1) * Ns + N_r,:);
        Fp((kk-1) * N_p + 1 :  kk * N_p,:) = F((kk-1) * Ns + N_r + 1 : kk * Ns,:);
    end

    rate_store = rate_old;
    RateOld = 0;
    tradeoff_store = [];
    for in_iter = 1 : 50
        %-----------------------------optimize u-----------------------------
        u = zeros(1,K);
        for kk = 1 : K
            u(kk) = F(:,kk)' * H(:,kk)/(sum(abs(H(:,kk)' * F).^2) + sigma2);
        end

        if in_iter > 1
            tradeoff_store = [tradeoff_store, TradeOffCalculate(H,F,u,v,K,sigma2)];
        end
        %-----------------------------optimize v-----------------------------
        v = zeros(1,K);
        for kk = 1 : K
            hkF = H(:,kk)' * F;   % 1xK
            e_k = abs(1 - u(kk)*hkF(kk))^2 ...
            + abs(u(kk))^2 * (sum(abs(hkF).^2) - abs(hkF(kk))^2 + sigma2);
            v(kk) = 1 / e_k;
        end

        if in_iter > 1
            tradeoff_store = [tradeoff_store, TradeOffCalculate(H,F,u,v,K,sigma2)];
        end
        % -----------------------------optimize yk-----------------------------
        objective_function = @(x) PassivePinchingAntennaPositionOptimizationObj(x,channelParam,bsAxisX,lambda_c,lambda_g,waveguidePosNormGrid,N_RF,u,v,Ha,Fa,Fp,channelGainScale);
        options = optimoptions('fmincon', 'Algorithm', 'sqp', 'Display', 'iter');
        [AntennaPostionNew, ~] = fmincon(objective_function, AntennaPostionIni', Aneq, bneq, [], [], lb,ub,[],options);
        Hp = sqrt(channelGainScale) * ChannelGenerationPassive(AntennaPostionNew',channelParam,bsAxisX,lambda_c,lambda_g,waveguidePosNormGrid,N_RF);
        AntennaPostionIni = AntennaPostionNew';
        % Update Channels
        H = zeros(N_t,N_RF);
        for kk = 1 : N_RF
            H((kk-1)*Ns +1 : (kk-1)*Ns + N_r,:) = Ha((kk-1)*N_r +1 : kk*N_r,:);
            H((kk-1)*Ns +1 + N_r :  kk * Ns,:) = Hp((kk-1)*N_p +1 :  kk * N_p,:);
        end


        tradeoff_store = [tradeoff_store, TradeOffCalculate(H,F,u,v,K,sigma2)];


        % ---------------------------Optimize F_RF----------------------------
        % Obtain Frfb
        Frfb = zeros(N_p * N_RF,N_RF);
        for kk = 1 : N_RF
            Frfb((kk-1) * N_p + 1 : kk * N_p,kk) = ones(N_p,1); 
        end


        Mu = zeros(K,K);
        for kk = 1 : K
            for ii = 1 : K
                if kk == ii
                    hpk = Hp(:,kk);
                    fpi = Fp(:,ii);
                    Mu(kk,ii) = u(kk) * hpk' * fpi - 1;
                else
                    hpk = Hp(:,kk);
                    fpi = Fp(:,ii);
                    Mu(kk,ii) = u(kk) * hpk' * fpi;
                end
            end
        end

        Q = zeros(N_r * N_RF,N_r * N_RF);
        q = zeros(N_r * N_RF,1);
        for kk = 1 : K
            for ii = 1 : K
                hk = Ha(:,kk);
                wi = F_BB(:,ii);
                h_ki = hk .* conj(repelem(wi, N_r));
                Q = Q + v(kk) * abs(u(kk))^2 * (h_ki * h_ki');
                q = q + v(kk) * conj(u(kk)) * h_ki * Mu(kk,ii);
            end
        end
        cvx_begin quiet
        variable frf(N_r * N_RF,1) complex   
        expression Frfa(N_r * N_RF, N_RF)     
        for kk = 1:N_RF
            row_idx = (kk-1)*N_r + (1:N_r);    
            Frfa(row_idx, kk) = frf((kk-1)*N_r + (1:N_r)); 
        end

        minimize real( quad_form(frf, Q) + 2 * real(q' * frf) )
        subject to
        for nn = 1 : N_r * N_RF
            square_abs(frf(nn)) <= 1;
        end

        norm(Frfa * F_BB,'fro') <= sqrt(P_tx - norm(Frfb * F_BB,'fro')^2);
        cvx_end
        % Reconstruct F_RF
        for kk = 1 : N_RF
            for nn = 1 : N_r
                F_RF((kk-1) * Ns + nn,kk) = frf((kk-1) * N_r + nn);
            end
        end
        % Reconstruct F;
        F = F_RF * F_BB;
        % Update Fa 和 Fp
        Fa = zeros(N_r * N_RF,N_RF);
        Fp = zeros(N_p * N_RF,N_RF);
        for kk = 1 : N_RF
            Fa((kk-1) * N_r + 1 :  kk * N_r,:) = F((kk-1) * Ns + 1 : (kk-1) * Ns + N_r,:);
            Fp((kk-1) * N_p + 1 :  kk * N_p,:) = F((kk-1) * Ns + N_r + 1 : kk * Ns,:);
        end

        tradeoff_store = [tradeoff_store, TradeOffCalculate(H,F,u,v,K,sigma2)];

        % -----------------------------Optimize F_BB-----------------------------
        Overline_Hk = zeros(K,K);
        for kk = 1 : K
            Overline_Hk(kk,:) = u(kk) * H(:,kk)' * F_RF;
        end
        T = zeros(K,K);
        S = zeros(K,K);
        for kk = 1 : K
            T = T + v(kk) * Overline_Hk(kk,:)' * Overline_Hk(kk,:);
            S(:,kk) = v(kk) * Overline_Hk(kk,:)';
        end
        overlineP = kron(eye(K),T);
        overlinep = S(:);
        overlineFrf = kron(eye(K),F_RF);
        cvx_begin quiet
        variable fbb(K^2,1) complex
        minimize(( quad_form(fbb, overlineP) - 2 * real(overlinep' * fbb) ) )
        subject to
        norm(overlineFrf * fbb) <= sqrt(P_tx);
        cvx_end
        % Reconstruct F_BB
        F_BB = reshape(fbb,K,K);
        F_BB = F_BB / norm(F_RF*F_BB,'fro') * sqrt(P_tx);
        % Reconstruct F;
        F = F_RF * F_BB;
        % Update Fa 和 Fp
        Fa = zeros(N_r * N_RF,N_RF);
        Fp = zeros(N_p * N_RF,N_RF);
        for kk = 1 : N_RF
            Fa((kk-1) * N_r + 1 :  kk * N_r,:) = F((kk-1) * Ns + 1 : (kk-1) * Ns + N_r,:);
            Fp((kk-1) * N_p + 1 :  kk * N_p,:) = F((kk-1) * Ns + N_r + 1 : kk * Ns,:);
        end

        tradeoff_store = [tradeoff_store, TradeOffCalculate(H,F,u,v,K,sigma2)];

        % -----------------------------Rate Calculation-----------------------------
        Ratenew = RateCal(H,F_RF,F_BB,P_tx,sigma2,K);
        [rate_store] = [rate_store,Ratenew];
        %     if abs(Ratenew - RateOld)< 1e-2
        %         break;
        %     end
        RateOld = Ratenew;

        if in_iter > 40 
            if (rate_store(in_iter) - rate_store(in_iter-1))<0.02
                break;
            end
        end
    end
    Position = AntennaPostionNew;
end


function Ratenew = RateCal(H,F_RF,F_BB,P_tx,sigma2,K)

    F_BB = F_BB/norm(F_RF * F_BB,'fro') * sqrt(P_tx);
    % Rate Calculation
    Ratenew = sum_rate_cal(H,F_RF * F_BB,sigma2,K);

end

function tradeoff = TradeOffCalculate(H,F,u,v,K,sigma2)
    tradeoff = 0;

    for kk = 1 : K
        ek = abs(u(kk))^2 * sigma2;
        for ii = 1 : K
            if  ii ~= kk
                ek = ek + abs(u(kk) * H(:,kk)' * F(:,ii))^2;
            else
                ek = ek + abs(u(kk) * H(:,kk)' * F(:,ii) - 1)^2;
            end
        end
        tradeoff = tradeoff + v(kk) * ek - log(v(kk));
    end

end
