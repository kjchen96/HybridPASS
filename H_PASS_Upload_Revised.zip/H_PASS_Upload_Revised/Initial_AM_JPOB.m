function initData = Initial_AM_JPOB(F_RF,F_BB,N_RF,N_t,N_r,N_p,bsAxisY,H)
%Initial_AM_JPOB  Initialization for the AM_JPOB alternating-minimization routine
%
%   initData = Initial_AM_JPOB(F_RF, F_BB, N_RF, N_t, N_r, N_p, bsAxisY, H)
%
% This helper creates an initialization (e.g., discrete/continuous PA locations and related
% bookkeeping variables) using the current precoder and channel realization.
%
% Inputs
%   F_RF, F_BB : current analog/digital precoders
%   N_RF, N_t, N_r, N_p : system dimensions
%   bsAxisY    : waveguide y-axis coordinates (geometry)
%   H          : composite channel matrix
%
% Output
%   initData   : struct used by AM_JPOB (fields match the original implementation)

    Ns = N_t/N_RF;            % Number of Antennas for Wach Waveguide
    N_c = Ns - N_r;
    HalfN = N_c/2;


    initData.Fbb = F_BB;
    InitPosition = [];
    InitFrf = cell(N_RF);
    for kk = 1 : N_RF
        InitFrfkk = [];
        for nn = 1 : Ns
            if (nn >= HalfN + 1) && (nn <= HalfN + N_r)
                InitFrfkk = [InitFrfkk;F_RF((kk - 1) * Ns + nn,kk)];
            end
        end
        for nn = 1 : Ns
            if (nn <= HalfN) || (nn >= HalfN + N_r + 1)
                if abs(F_RF((kk - 1) * Ns + nn,kk)) > 0 
                    InitPosition = [InitPosition,bsAxisY(nn)];
                    InitFrfkk = [InitFrfkk;F_RF((kk - 1) * Ns + nn,kk)];
                end
            end
        end
        InitFrf{kk,1} = InitFrfkk;
    end

    InitFrf2 = zeros((N_r + N_p) * N_RF,N_RF);
    for kk = 1 : N_RF
        InitFrf2((kk - 1) * (N_r + N_p) + 1 : kk * (N_r + N_p),kk) =  InitFrf{kk,1} ;
    end
    initData.Position = InitPosition;
    initData.Frf = InitFrf2;


    Hn = zeros(N_t,N_RF);
    for kk = 1 : N_RF
        Hn((kk-1)*Ns +1 : (kk-1)*Ns + N_r,:) = H((kk-1)*Ns + HalfN + 1 : (kk-1)*Ns + HalfN + N_r,:);
        Hn((kk-1)*Ns +N_r + 1 : (kk-1)*Ns + N_r + HalfN,:) = H((kk-1)*Ns + 1 : (kk-1)*Ns + HalfN,:);
        Hn((kk-1)*Ns +N_r + HalfN + 1 : (kk-1)*Ns + Ns,:) = H((kk-1)*Ns +N_r + HalfN + 1 : (kk-1)*Ns + Ns,:);
    end
    initData.H =Hn;
end

