function rate  = sum_rate_cal(H,F,sigma2,K)
%sum_rate_cal  Compute the sum spectral efficiency (sum-rate) for a given precoder
%
%   sum_rate = sum_rate_cal(H, F, sigma2, K)
%
% Inputs
%   H      : channel matrix (size: N_total x K), where column k is the channel of user k
%   F      : precoding matrix (size: N_total x K), where column k is the precoder for user k
%   sigma2 : noise power (normalized)
%   K      : number of users
%
% Output
%   sum_rate : sum_k log2(1 + SINR_k)

    rate = 0;
    for k = 1 : K
        P_S = abs(H(:,k)' * F(:,k))^2;         % Signal power
        P_I = sum(abs(H(:,k)' * F).^2) - P_S;  % Interference power
        rate = rate + log2(1 + P_S/(sigma2 + P_I));
    end
end
