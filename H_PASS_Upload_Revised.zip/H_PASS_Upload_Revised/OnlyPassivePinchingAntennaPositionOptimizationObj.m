function   objective_function = OnlyPassivePinchingAntennaPositionOptimizationObj(x,channelParam,bsAxisX,lambda_c,lambda_g,waveguidePosNormGrid,N_RF,u,v,Fp,channelGainScale) 
%OnlyPassivePinchingAntennaPositionOptimizationObj  Objective function for passive-only PA position updates
%
% See PassivePinchingAntennaPositionOptimizationObj. This variant corresponds to the passive-only case.
%

    x = x';
    objective_function = 0;
    Hp = sqrt(channelGainScale) * ChannelGenerationPassive(x,channelParam,bsAxisX,lambda_c,lambda_g,waveguidePosNormGrid,N_RF);

    for kk = 1 : N_RF
        ek = abs(1 - u(kk) * Hp(:,kk)' * Fp(:,kk))^2 +...
        sum(abs(u.* (Hp(:,kk)' * Fp) ).^2)   - ...
        abs(u(kk)* (Hp(:,kk)' * Fp(:,kk))).^2;
        objective_function = objective_function + v(kk) * ek;
    end

end
