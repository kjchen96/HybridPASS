function [x,x_left, x_middle, x_right] = generate_array_positions(N_s, N_r, d_pa, d_rlwa)
%generate_array_positions  Generate y-axis coordinates for candidate PA positions and RLWA reference points
%
%   [antennaPositionY, x_left, x_middle, x_right] = generate_array_positions(N_s, N_r, d_pa, d_rlwa)
%
% Inputs
%   N_s    : number of candidate PA positions per waveguide
%   N_r    : number of RLWAs per waveguide
%   d_pa   : candidate-grid spacing between adjacent PAs (normalized)
%   d_rlwa : spacing between adjacent RLWAs (normalized)
%
% Outputs
%   antennaPositionY : y-axis coordinates of candidate PA positions (length N_s)
%   x_left/x_middle/x_right : auxiliary indices used by the geometry model

    if mod(N_s - N_r, 2) ~= 0
        error('N_s - N_r must be even to maintain symmetry.');
    end

    Nl = (N_s - N_r) / 2;  % number of elements on the left side
    Nr = Nl;             % number of elements on the right side

    % Indices for the center elements: n = Nl : Nl+N_r-1
    middle_idx = 0 : N_r-1;
    middle_center = (N_r - 1) / 2;
    x_middle = (middle_idx - middle_center) * d_rlwa;

    % Left elements: extend left from the first center element
    x_left = x_middle(1) - d_pa * (Nl:-1:1);

    % Right elements: extend right from the last center element
    x_right = x_middle(end) + d_pa * (1:Nr);

    % Concatenate all positions
    x = [x_left, x_middle, x_right];
end
