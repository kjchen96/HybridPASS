function initData = Initial_AM_JPOB_withoutActive(F_RF,F_BB,N_t,N_RF,N_p,bsAxisY)
%Initial_AM_JPOB_withoutActive  Initialization for AM_JPOB_withoutActive (passive-only case)
%
%   initData = Initial_AM_JPOB_withoutActive(F_RF, F_BB, N_t, N_RF, N_p, bsAxisY)
%
% Inputs
%   F_RF, F_BB : current analog/digital precoders
%   N_t, N_RF, N_p : system dimensions (see MainFunction for definitions)
%   bsAxisY    : waveguide y-axis coordinates (geometry)
%
% Output
%   initData   : struct used by AM_JPOB_withoutActive (fields match the original implementation)

    Ns = N_t/N_RF;
    initData.Fbb = F_BB;
    InitPosition = [];
    InitFrf = cell(N_RF);
    for kk = 1 : N_RF
        InitFrfkk = [];
        for nn = (kk - 1) * Ns + 1 : kk * Ns
            if abs(F_RF(nn,kk)) > 0 
                InitPosition = [InitPosition,bsAxisY(nn)];
                InitFrfkk = [InitFrfkk;F_RF(nn,kk)];
            end
        end
        InitFrf{kk,1} = InitFrfkk;
    end

    InitFrf2 = zeros( N_p  * N_RF,N_RF);
    for kk = 1 : N_RF
        InitFrf2((kk - 1) * N_p + 1 : kk * N_p,kk) =  InitFrf{kk,1} ;
    end
    initData.Position = InitPosition;
    initData.Frf = InitFrf2;
end

