function [H,H2,channelParam] = ChannelGenerationContinuous(N_t,K,L,r_min,r_max,bsAxisX,bsAxisY,bsAxisY2,bsAxisZ,lambda_c)
%ChannelGenerationContinuous  Generate channel matrices for the considered continuous-position model
%
%   [H, H2, channelParam] = ChannelGenerationContinuous(N_t, K, L, r_min, r_max, bsAxisX, bsAxisY, bsAxisY2, bsAxisZ, lambda_c)
%
% Outputs
%   H            : composite channel matrix for the H-PASS case (active + passive components)
%   H2           : composite channel matrix for the passive-only benchmark
%   channelParam : geometry/channel parameters reused by AM_JPOB-based routines
    H = zeros(N_t,K);
    H2 = zeros(N_t,K);

    neff = 1.44;
    lambda_g = lambda_c/neff;

    Rminx = r_min(1);
    Rminy = r_min(2);
    Rmaxx = r_max(1);
    Rmaxy = r_max(2);
    % 
    UserAxisXStore = zeros(K,L);
    UserAxisYStore = zeros(K,L);
    AmplitudeStore = zeros(K,L);
    for kk = 1 : K
        for ll = 1 : L
            UserAxisX = rand * (Rmaxx - Rminx) + Rminx;
            UserAxisY = rand *  (Rmaxy - Rminy) + Rminy;
            UserAxisZ = 0;

            FreeSpacePropogation = sqrt((UserAxisX - bsAxisX).^2 + (UserAxisY - bsAxisY).^2 + (UserAxisZ - bsAxisZ).^2);
            %         InWaveGuidePropogation = mod((1:N_t)',round(N_t/N_RF)) *d;
            FreeSpacePropogation2 = sqrt((UserAxisX - bsAxisX).^2 + (UserAxisY - bsAxisY2).^2 + (UserAxisZ - bsAxisZ).^2);

            InWaveGuidePropogation = bsAxisY;
            InWaveGuidePropogation2 = bsAxisY2;

            PhasePropogation = exp(- 1j * 2 * pi * FreeSpacePropogation/lambda_c - 1j * 2 * pi * InWaveGuidePropogation/lambda_g);
            PhasePropogation2 = exp(- 1j * 2 * pi * FreeSpacePropogation2/lambda_c - 1j * 2 * pi * InWaveGuidePropogation2/lambda_g);

            WaveGuideLoss1 = exp(-0.01 * abs(bsAxisY - bsAxisY(1)));
            WaveGuideLoss2 = exp(-0.01 * abs(bsAxisY - bsAxisY2(1)));
            if ll == 1 % LoS path
                Amplitude = lambda_c./FreeSpacePropogation/4/pi;
                Amplitude2 = lambda_c./FreeSpacePropogation2/4/pi;

                complexGain = 1;
            else % NLoS paths
                Amplitude = lambda_c./FreeSpacePropogation/4/pi;
                Amplitude2 = lambda_c./FreeSpacePropogation/4/pi;

                complexGain = (randn + 1j * randn)/sqrt(2) * 0.1;
                Amplitude = Amplitude * complexGain;
                Amplitude2 = Amplitude2 * complexGain;

            end
            H(:,kk) = H(:,kk) + Amplitude.*WaveGuideLoss1.* PhasePropogation;
            H2(:,kk) = H2(:,kk) + Amplitude2.* WaveGuideLoss2 .* PhasePropogation2;

            % - - - - Store - - - -
            UserAxisXStore(kk,ll) = UserAxisX;
            UserAxisYStore(kk,ll) = UserAxisY;
            AmplitudeStore(kk,ll) = complexGain;
        end
    end

    % - - - - Store - - - -
    channelParam.UserAxisXStore = UserAxisXStore;
    channelParam.UserAxisYStore = UserAxisYStore;
    channelParam.AmplitudeStore = AmplitudeStore;
    channelParam.Height = bsAxisZ;
    channelParam.L = L;
end
