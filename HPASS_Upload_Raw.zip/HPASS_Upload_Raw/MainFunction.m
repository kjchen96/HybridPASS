%% Hybrid PASS
clear all;
close all;
%% Setting
c = 3e8;              % Speed of light
fc = 30e9;            % Carrier Frequency
lambda = c/fc;        % Carrier Wavelength
Nt = 1000;            % Total Number of PAs
d1 = lambda/2 * 8;    % Antenna Spacing for Candidate Discrete-Position PAs
d2 = lambda/2;        % Antenna Spacing for RLWAs

spacing = lambda/2;   % Minimum Spacing for Continuous-Position PAs
K = 4;               % Number of Users
Nrf = 4;              % Number of Waveguides/RF chains
Ns = Nt/Nrf;          % Number of Antennas in each waveguide
%% Monte Carol Simulation
Nr = 8;               % Number of RLWAs
Np = 16;              % Number of PAs
%% Basic Setting
D = (Ns-Nr) * d1 + Nr * d2;         % Array Aperture
L = 6;              % Number of Channel Paths
sigma2 = 1;
%% Coordinate
Height = 3;          % Height of Waveguides
Width = 10;          % width of the service region
Length = 30;         % length of the service region
BsAxisX = kron(linspace(Length/2/Nrf,Length-Length/2/Nrf,Nrf)',ones(Ns,1));                     % Candidate Antennas x-axis 
% BsAxisX = 0;
[BsAxisY1,x_left, x_middle, x_right] = generate_array_positions(Ns, Nr, d1, d2);
BsAxisY = kron(ones(Nrf,1),BsAxisY1');     % Candidate Antennas y-axis 
BsAxisZ = ones(Nt,1) * Height;             % Candidate Antennas z-axis 
BsAxisY2 = kron(ones(Nrf,1),(-(Ns-1)/2 : 1 : (Ns-1)/2)' * d1); % Candidate Antennas y-axis 

Rmin = [0,-Width/2];                       % minimum communication distance
Rmax = [Length,Width/2];                   % maximum communication distance
% Boundaries for Continuous-Position PAs
UserYRegionLeft = zeros(Nrf,1);
UserYRegionRight = zeros(Nrf,1);
UserYRegionLeft2 = zeros(Nrf,1);
UserYRegionRight2 = zeros(Nrf,1);
UserYRegionLeft3 = zeros(Nrf,1);
UserYRegionRight3 = zeros(Nrf,1);
InWaveguidePositionNorm = zeros(Nrf,1);
for ii = 1 : Nrf
    UserYRegionLeft(ii) = -D/2;
    UserYRegionRight(ii) = D/2;
    UserYRegionLeft2(ii) = x_left(1);
    UserYRegionRight2(ii) = x_left(end);
    UserYRegionLeft3(ii) = x_right(1);
    UserYRegionRight3(ii) = x_right(end);
end



%% Transmit Power
NoisePower = 10^(-11);             % linear
%% Start
% Channel Generation
[H,H2,ChannelPara] = ChannelGenerationContinuous(Nt,K,L,Rmin,Rmax,BsAxisX,BsAxisY,BsAxisY2,BsAxisZ,lambda);

% Power Normarlization to prevent numerical inaccuracy due to very small values
TransmitPowerdBM = 10;
TransmitPowerLinear = 10^((TransmitPowerdBM - 30)/10);
Factor = 1/(mean(abs(H(:)).^2));
H = H * sqrt(Factor);   % Normalize the average channel power (squared magnitude) to 1
H2 = H2 * sqrt(Factor);
TransmitPowerLinear = 1/NoisePower/Factor * TransmitPowerLinear; % Adjust transmit power so that the noise power is 1

%% Hybrid PASS with Discrete-Position Passive PAs
[Frf1,Fbb1,Rate_Store1] =  PT_JADB(Nt,Nr,Np,Nrf,sigma2,TransmitPowerLinear,K,H,0.9);
%% Hybrid PASS with Continuous-Position Passive PAs
Init2 = Initial_AM_JPOB(Frf1,Fbb1,Nrf,Nt,Nr,Np,BsAxisY,H);      
[Frf2,Fbb2,Rate_Store2,Position2,TradeOffStore2] = AM_JPOB(Nr,Nrf,sigma2,TransmitPowerLinear,K,Np,spacing,lambda,ChannelPara,BsAxisX,UserYRegionLeft2,UserYRegionRight2,UserYRegionLeft3,UserYRegionRight3,InWaveguidePositionNorm,Factor,Init2);
%% R-PASS
[Frf3,Fbb3,Rate_Store3] =  PT_JADB(Nt,Nr,0,Nrf,sigma2,TransmitPowerLinear,K,H,0.9);
%% P-PASS with Discrete-Position Passive PAs
[Frf4,Fbb4,Rate_Store4] =  PT_JADB(Nt,0,Np,Nrf,sigma2,TransmitPowerLinear,K,H2,0.9);
%% P-PASS with Continuous-Position Passive PAs
Init5 = Initial_AM_JPOB_withoutActive(Frf4,Fbb4,Nt,Nrf,Np,BsAxisY2);      
[Frf5,Fbb5,Rate_Store5,Position5,TradeOffStore5] = AM_JPOB_withoutActive(Nrf,sigma2,TransmitPowerLinear,K,Np,spacing,lambda,ChannelPara,BsAxisX,UserYRegionLeft,UserYRegionRight,InWaveguidePositionNorm,Factor,Init5);


%% Plot Figure
plot(Rate_Store1(2:end),'bo-','linewidth',1.5,'markersize',8);
hold on;
plot(Rate_Store2,'rs-','linewidth',1.5,'markersize',8);
plot(Rate_Store3(2:end),'>-','color',[0 0.5 0],'linewidth',1.5,'markersize',8);
plot(Rate_Store4(2:end),'kx-','linewidth',1.5,'markersize',8);
plot(Rate_Store5,'mp-','linewidth',1.5,'markersize',8);

legend('DH-PASS','CH-PASS','R-PASS','DP-PASS','CP-PASS')